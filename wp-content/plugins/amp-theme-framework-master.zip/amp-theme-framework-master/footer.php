</div>
<footer class="footer container">
	<?php amp_non_amp_link(); ?>
</footer>
<?php amp_footer_core(); ?>