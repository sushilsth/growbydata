<?php amp_header(); ?>
<?php amp_title(); ?>
<?php amp_featured_image(); ?>
<?php amp_content(); ?>
<?php amp_footer(); ?>